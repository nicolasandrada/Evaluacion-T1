// Seleccionar los elementos de tipo radio para el tipo de motor
let tipoMotorRadios = document.querySelectorAll("input[type=radio]");

// evento de cambio a cada radio del btnn de tipoMotorRadios
tipoMotorRadios.forEach(tipoMotorRadio => {
  tipoMotorRadio.addEventListener('change', event => {
    let containerVueltas = document.querySelector('.container_vueltas');
    if (event.target.value == 'monofasico') {
      // Si el tipo de motor es monofásico, 1 fase
      containerVueltas.innerHTML = `
        <h3>Cantidad de vueltas</h3>
        <h4>Fase 1<h4>
        <input type='number' name='fase[]'>`;
    } else {
      // else trifásica, mostrar tres fases
      containerVueltas.innerHTML = `
        <h3>Cantidad de vueltas</h3>
        <h4>Fase 1<h4>
        <input type='number' name='fase[]'>
        <h4>Fase 2<h4>
        <input type='number' name='fase[]'>
        <h4>Fase 3<h4>
        <input type='number' name='fase[]'>`;
    }
  });
});




///////////////////////////////////////////////
//Funcion para la accion de apretar en calcular
let bt_calcular = document.getElementById('calcular')
bt_calcular.addEventListener('click',e=>{
    let total = totalDeAlambre()
    calcularTotalPrecio(total)
})

 // 1) Funcion para calcular el total de material gastado
 
function totalDeAlambre() {
    //no se por que es necesesario el tipo de motor, pero lo dejo por las dudas aunque si no esta funciona igual
    let tipo_motor = document.querySelector('input[name=tipo]:checked').value
    // Devuelve la cantidad de ranuras del motor
    let cant_ranuras = parseInt(document.getElementById('ranuras').value);
    // Devuelve el largo del nucleo (en cm)
    let largo_nucleo = parseInt(document.getElementById('nucleo').value);

    // Conversión de cm a mts 
    let largo_nucleo_m = largo_nucleo / 100;

    // Recorre la/s fase/s y guarda el numero de vueltas en un arreglo
    let vueltas = [];
    document.getElementsByName("fase[]").forEach(input => {
        vueltas.push(parseInt(input.value));
    });

    let total = cant_ranuras * largo_nucleo_m * (vueltas.reduce((a, b) => a + b, 0));
    alert(`El total de material utilizado es:  ${total} mts`)

    return total;
}



 
    function calcularTotalPrecio(totalMaterial) {
        let diametro = document.getElementById('diametro').value;
        let totalPrecio;

        if (diametro == document.getElementById('diametro1').value) {
            totalPrecio = totalMaterial * 200;
            //and
        } else if (diametro == document.getElementById('diametro2').value || diametro == document.getElementById('diametro3').value) {
            totalPrecio = totalMaterial * 180;
            if (totalMaterial > 100) {
                totalPrecio *= 0.9; 
            }
        } else if (diametro == document.getElementById('diametro4').value) {
            totalPrecio = totalMaterial * 210;
        } else {
            alert(false) 
        }
               
        alert(`el total del precio es:$${totalPrecio}`)
        return totalPrecio;
        
    }


